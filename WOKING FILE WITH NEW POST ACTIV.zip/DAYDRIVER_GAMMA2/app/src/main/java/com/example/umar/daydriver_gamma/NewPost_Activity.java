package com.example.umar.daydriver_gamma;

import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;

public class NewPost_Activity extends Sucful_Reg_Page implements View.OnClickListener {
private Toolbar newpost_toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.newpost);
        newpost_toolbar=findViewById(R.id.newpost_toolbar);
        getSupportActionBar().setTitle("New Post");


    }
}
