package com.example.umar.daydriver_gamma;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.view.View;
import android.widget.Toolbar;

public class home extends Sucful_Reg_Page  {
         private Toolbar toolbar;
         FloatingActionButton home_addpost;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
     setContentView(R.layout.home);
     toolbar=findViewById(R.id.newpost_toolbar);
     home_addpost=findViewById(R.id.newpost_button);


     home_addpost.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View view) {
             Intent intent=new Intent(home.this,NewPost_Activity.class);
             startActivity(intent);
         }
     });



    }


}
