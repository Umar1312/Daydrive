package com.example.umar.daydriver_gamma;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

/**
 * Demonstrate Firebase Authentication using a Google ID Token.
 */
public class SigninClass extends MainActivity implements View.OnClickListener {
EditText age;
Spinner prof_select;
String proff;
String age_user;
Button reg;
private FirebaseFirestore mfirestore;
FirebaseAuth currentuser;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signin_activity);
       mfirestore=FirebaseFirestore.getInstance();

        Bundle b= getIntent().getExtras();
        final String id=b.getString("UID");

        age=(EditText)findViewById(R.id.editText_Age);

        final DocumentReference docref= mfirestore.collection("USERS").document(id);

        TextView prof=(TextView)findViewById(R.id.textView_prof);
        prof_select=(Spinner)findViewById(R.id.spinner_Profession);

        reg=(Button)findViewById(R.id.button);


        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final Intent intent=new Intent(SigninClass.this,Sucful_Reg_Page.class);
                age_user=age.getText().toString();
                proff= prof_select.getSelectedItem().toString();
                Map<String,String> usermap=new HashMap<>();
                usermap.put("USERNAME",id);
                usermap.put("Age",age_user);
                docref.set(usermap).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void avoid) {
                        Toast.makeText(SigninClass.this,"USER HAS REGISTERED",Toast.LENGTH_LONG).show();
                        startActivity(intent);
                    }
                });
                }
        });
    }
}