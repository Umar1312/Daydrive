package com.example.umar.daydriver_gamma;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.util.HashMap;
import java.util.Map;

public class NewPost_Activity extends MainActivity implements View.OnClickListener {
    private ImageView imageView;
    private EditText desc;
    private Uri postimageURI=null;
    private FirebaseFirestore firebase;
    private StorageReference storageReference;
     private FirebaseAuth mAuth;
     private String user_id;
     private String download_uri;
     private FieldValue timestamp;
     ProgressBar progressBar;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.newpost);
        imageView = findViewById(R.id.newpostImage);
        mAuth = FirebaseAuth.getInstance();
        user_id =mAuth.getCurrentUser().getDisplayName();
        firebase = FirebaseFirestore.getInstance();
        storageReference = FirebaseStorage.getInstance().getReference();
        Button post_btn = findViewById(R.id.post_button);
        desc = findViewById(R.id.post_Edittext);
        progressBar=findViewById(R.id.progressBar);


        post_btn.setOnClickListener(new View.OnClickListener()

        {
            @Override
            public void onClick(View v) {
                progressBar.setVisibility(View.VISIBLE);
                final String descr = desc.getText().toString();
                String randomname=FieldValue.serverTimestamp().toString();

                if (!TextUtils.isEmpty(descr) && postimageURI != null) {

                    StorageReference file_path = storageReference.child("POST_IMAGES").child(randomname + ".jpg");

                    file_path.putFile(postimageURI).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                            if (task.isSuccessful()) {
                                 download_uri = task.getResult().getDownloadUrl().toString();

                                Map<String,Object> postmap = new HashMap<>();
                                postmap.put("DESCRIPTION", descr);
                                postmap.put("IMAGE_URI",download_uri);
                                postmap.put("USER_ID", user_id);
                                postmap.put("TIME", FieldValue.serverTimestamp()).toString();

                                firebase.collection("POSTS").add(postmap);
                                progressBar.setVisibility(View.INVISIBLE);

                                startActivity(new Intent(NewPost_Activity.this,home.class));
                            } else {

                                Toast.makeText(NewPost_Activity.this,"ERRR",Toast.LENGTH_SHORT).show();
                            }


                        }
                    });

                }
                else
                    {
                    Toast.makeText(NewPost_Activity.this, "ERROR", Toast.LENGTH_SHORT).show();
                }
            }

        });


        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CropImage.activity()
                        .setGuidelines(CropImageView.Guidelines.ON).setAspectRatio(1, 1)
                        .start(NewPost_Activity.this);
            }
        });
    }
        @Override
        public void onActivityResult ( int requestCode, int resultCode, Intent data){
            super.onActivityResult(requestCode, resultCode, data);
            if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
                CropImage.ActivityResult result = CropImage.getActivityResult(data);
                if (resultCode == RESULT_OK) {
                    postimageURI = result.getUri();
                    imageView.setImageURI(postimageURI);
                } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                    Exception error = result.getError();
                }
            }
        }

    }



