package com.example.umar.daydriver_gamma;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Nonnull;


/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {

    private FirebaseFirestore firestore;
    private RecyclerView bloglist_view;
    private List<homepost> blog_list;
    private HomerecyclerAdapter homerecyclerAdapter;

    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(@Nonnull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_home,container,false);
        blog_list=new ArrayList<>();//A NEW LIST OF ITEMS ARE CREATED
        bloglist_view=view.findViewById(R.id.bloglist_view_FRAGHOME);//REFERENCE TO THE XML FILE CONTAINING THE LAYOUT(IN THIS CASE IT IS blog_list_item) OR WHAT YOU CAN CALL A SINGLE CARD
        homerecyclerAdapter=new HomerecyclerAdapter(blog_list);
        bloglist_view.setLayoutManager(new LinearLayoutManager(container.getContext()));//BOILER PLATE CODE
        bloglist_view.setAdapter(homerecyclerAdapter);
        firestore=FirebaseFirestore.getInstance();
        Query firstquery=firestore.collection("POSTS").orderBy("TIME", Query.Direction.DESCENDING);//THIS IS DONE TO SORT POSTS BY THEIR TIME
          firstquery.addSnapshotListener(new EventListener<QuerySnapshot>() {
              @Override
              public void onEvent( QuerySnapshot DocumentSnapshots,FirebaseFirestoreException e) {
                  for(DocumentChange doc: DocumentSnapshots.getDocumentChanges())
                  {

                      if(doc.getType() == DocumentChange.Type.ADDED)
                      {

                          homepost Home_post = doc.getDocument().toObject(homepost.class);
                          blog_list.add(Home_post);
                          homerecyclerAdapter.notifyDataSetChanged();
                      }
                            else
                          {
                              Toast.makeText(getActivity(),"FAILED",Toast.LENGTH_SHORT).show();
                          }


                  }

              }
          });


        // Inflate the layout for this fragment
        return view;
    }

}
