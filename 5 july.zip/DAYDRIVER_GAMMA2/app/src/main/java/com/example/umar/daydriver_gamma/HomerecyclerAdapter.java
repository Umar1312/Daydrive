package com.example.umar.daydriver_gamma;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class HomerecyclerAdapter extends RecyclerView.Adapter<HomerecyclerAdapter.ViewHolder> {



    public List<homepost> homepostList;
    public Context context;

    private FirebaseFirestore firestore;
    private TextView username;
    private CircleImageView user_image;

   public HomerecyclerAdapter(List<homepost> homepostList) {
       this.homepostList = homepostList;


   }



    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
       View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.blog_list_item,parent,false);
       context=parent.getContext();
       firestore=FirebaseFirestore.getInstance();
       return new ViewHolder(view);


    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
         String descdata=homepostList.get(position).getDESCRIPTION();
      holder.setDesctext(descdata);
        String image_url=homepostList.get(position).getIMAGE_URI();
        holder.setPostimage(image_url);

        String userid=homepostList.get(position).getUSER_ID();
        holder.setUsername(userid);
        firestore.collection("USERS").document(userid).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {

                    String userimage = task.getResult().getString("Userimage");
                    holder.setUserimage(userimage);




                }

                else {

                    //FIREBASE EXCEPTION
                }
            }});


   }

    @Override
    public int getItemCount() {
        return homepostList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private View mview;
        private TextView descview;
        private ImageView blog_image;
        private TextView userid;

        public ViewHolder(View itemView) {
            super(itemView);
            mview = itemView;

        }


        public void setDesctext(String desctext)

        {
            descview = mview.findViewById(R.id.desc_HOMEFRAG);
            descview.setText(desctext);

        }


        public void setPostimage(String downloaduri) {
            blog_image = mview.findViewById(R.id.imageView_HOMEFRAG);
            Glide.with(context).load(downloaduri).into(blog_image);


        }

        public void setUsername(String username) {
            userid = mview.findViewById(R.id.usernametext_HOMEFRAG);
            userid.setText(username);


        }


        public void setUserimage(String userimage)

        {
            user_image=mview.findViewById(R.id.user_image_HOME);
            RequestOptions requestOptions=new RequestOptions();
            requestOptions.placeholder(R.drawable.ellipse);


            Glide.with(context).applyDefaultRequestOptions(requestOptions).load(userimage).into(user_image);






        }
    }

}


