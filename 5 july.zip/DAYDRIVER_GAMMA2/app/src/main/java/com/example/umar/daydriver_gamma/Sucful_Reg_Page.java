package com.example.umar.daydriver_gamma;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class Sucful_Reg_Page extends MainActivity{

           Uri mainimage=null;
           private StorageReference storageReference;
private FirebaseAuth mfirebase;
private FirebaseFirestore db;
 private String username;
    DocumentReference documentReference;

     CircleImageView imageview;
     Button btn;
     ProgressBar progressBar;
    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.succpage);
        mfirebase=FirebaseAuth.getInstance();
        username=mfirebase.getCurrentUser().getDisplayName();
        storageReference= FirebaseStorage.getInstance().getReference();
      db=FirebaseFirestore.getInstance();

     documentReference =db.collection("USERS").document(username);
        imageview=findViewById(R.id.circleimageview);
        btn=findViewById(R.id.button_submit);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String userid= mfirebase.getCurrentUser().getUid();
                StorageReference image_path=storageReference.child("PROFILE IMAGES").child(userid +".jpg");
                image_path.putFile(mainimage).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                        if (task.isSuccessful())
                        {
                            String download_uri=task.getResult().getDownloadUrl().toString();
                            Map<String,String> usermap=new HashMap<>();
                            usermap.put("Userimage", download_uri);
                            documentReference.set(usermap).addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {

                                    Toast.makeText(Sucful_Reg_Page.this,"UPLOADED",Toast.LENGTH_LONG).show();
                                    Intent intent=new Intent(Sucful_Reg_Page.this,home.class);
                                    startActivity(intent);

                                }
                            });


                        }
                        else


                        {
                            Toast.makeText(Sucful_Reg_Page.this,"Failed",Toast.LENGTH_LONG).show();
                        }
                    }
                });


            }
        });


        imageview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
              {
                  if(ContextCompat.checkSelfPermission(Sucful_Reg_Page.this, Manifest.permission.READ_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED)
                  {
                      Toast.makeText(Sucful_Reg_Page.this, "ACCESS DENIED", Toast.LENGTH_LONG).show();

                      ActivityCompat.requestPermissions(Sucful_Reg_Page.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
                  }

                else {
                      CropImage.activity()
                              .setGuidelines(CropImageView.Guidelines.ON)
                              .start(Sucful_Reg_Page.this);
                  }

            }
        }});
    }




    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {
                mainimage = result.getUri();
                imageview.setImageURI(mainimage);
            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Exception error = result.getError();
            }
        }
    }


}