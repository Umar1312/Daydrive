package com.example.umar.daydriver_gamma;

public class homepost {

   public homepost(){

   }
    private String USER_ID,DESCRIPTION,IMAGE_URI;

    public homepost(String USER_ID, String DESCRIPTION, String IMAGE_URI) {
        this.USER_ID = USER_ID;
        this.DESCRIPTION = DESCRIPTION;
        this.IMAGE_URI = IMAGE_URI;
    }

    public String getUSER_ID() {
        return USER_ID;
    }

    public void setUSER_ID(String USER_ID) {
        this.USER_ID = USER_ID;
    }

    public String getDESCRIPTION() {
        return DESCRIPTION;
    }

    public void setDESCRIPTION(String DESCRIPTION) {
        this.DESCRIPTION = DESCRIPTION;
    }

    public String getIMAGE_URI() {
        return IMAGE_URI;
    }

    public void setIMAGE_URI(String IMAGE_URI) {
        this.IMAGE_URI = IMAGE_URI;
    }



}
