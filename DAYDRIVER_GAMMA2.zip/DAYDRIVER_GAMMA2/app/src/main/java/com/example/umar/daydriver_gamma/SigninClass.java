package com.example.umar.daydriver_gamma;

import android.os.Bundle;

/**
 * Demonstrate Firebase Authentication using a Google ID Token.
 */
public class SigninClass extends MainActivity  {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signin_activity);
    }
}
