package com.example.umar.daydriver_gamma;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.Toolbar;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class home extends Sucful_Reg_Page implements View.OnClickListener  {

         FloatingActionButton home_addpost;
         FirebaseFirestore firestore;
         private String user_id;
         FirebaseAuth mAuth;
         private Toolbar toolbar_home;
         private BottomNavigationView bottomNavigationView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
     setContentView(R.layout.home);
     firestore=FirebaseFirestore.getInstance();
     toolbar_home=findViewById(R.id.toolbar_home);
     setSupportActionBar(toolbar_home);
        getSupportActionBar().setTitle("HOME");
     home_addpost=findViewById(R.id.newpost_button);
      bottomNavigationView=findViewById(R.id.bottomnav_home);

     home_addpost.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View view) {
             Intent intent=new Intent(home.this,NewPost_Activity.class);
             startActivity(intent);
         }
     });



    }


}
