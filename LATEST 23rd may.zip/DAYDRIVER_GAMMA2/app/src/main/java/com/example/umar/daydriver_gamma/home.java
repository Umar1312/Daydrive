package com.example.umar.daydriver_gamma;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class home extends Sucful_Reg_Page implements View.OnClickListener  {

         FloatingActionButton home_addpost;
         FirebaseFirestore firestore;
         private String user_id;
         FirebaseAuth mAuth;
         private Toolbar toolbar_home;
         private BottomNavigationView bottomNavigationView;
         private HomeFragment homeFragment;
         private NotificationFragment notificationFragment;
         private AccountsFragment accountsFragment;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
     setContentView(R.layout.home);
     firestore=FirebaseFirestore.getInstance();
     toolbar_home=findViewById(R.id.toolbar_home);
     setSupportActionBar(toolbar_home);
        getSupportActionBar().setTitle("HOME");
     home_addpost=findViewById(R.id.newpost_button);
      bottomNavigationView=findViewById(R.id.bottomnav_home);
      //FRAGMENT INITIALIZE

        homeFragment=new HomeFragment();
        accountsFragment=new AccountsFragment();
        notificationFragment= new NotificationFragment();

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

               switch(item.getItemId()){
                   case R.id.Home_icon:

                       replaceFragment(homeFragment);
                       return  true;

                   case R.id.Notification_icon:
                           replaceFragment(notificationFragment);
                       return  true;
                   case R.id.Account_icon:
                       replaceFragment(accountsFragment);
                       return true;
                       default:
                           return false;




               }
            }
        });



     home_addpost.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View view) {
             Intent intent=new Intent(home.this,NewPost_Activity.class);
             startActivity(intent);
         }
     });



    }

    private void replaceFragment(Fragment fragment)
    {
        FragmentTransaction fragmentTransaction=getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.framelayout_HOME,fragment);
        fragmentTransaction.commit();


    }


}
