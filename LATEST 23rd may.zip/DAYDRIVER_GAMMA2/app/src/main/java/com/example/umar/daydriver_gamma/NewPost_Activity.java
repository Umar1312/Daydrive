package com.example.umar.daydriver_gamma;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.util.HashMap;
import java.util.Map;

public class NewPost_Activity extends MainActivity implements View.OnClickListener {
    private ImageView imageView;
    private EditText desc;
    private Uri postimageURI=null;
    private FirebaseFirestore firebase;
    private StorageReference storageReference;
     private FirebaseAuth mAuth;
     private String user_id;
     private String download_uri;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.newpost);
        imageView = findViewById(R.id.newpostImage);
        mAuth = FirebaseAuth.getInstance();
        user_id =mAuth.getCurrentUser().getUid();
        firebase = FirebaseFirestore.getInstance();
        storageReference = FirebaseStorage.getInstance().getReference();
        Button post_btn = findViewById(R.id.post_button);
        desc = findViewById(R.id.post_Edittext);



        post_btn.setOnClickListener(new View.OnClickListener()

        {
            @Override
            public void onClick(View v) {

                final String descr = desc.getText().toString();
                final String randomname = FieldValue.serverTimestamp().toString();

                if (TextUtils.isEmpty(descr) && postimageURI != null) {

                    StorageReference file_path = storageReference.child("POST_IMAGES").child(randomname + ".jpg");

                    file_path.putFile(postimageURI).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                            if (task.isSuccessful()) {
                                 download_uri = task.getResult().toString();

                                Map<String,Object> postmap = new HashMap<>();
                                postmap.put("DESCRIPTION", descr);
                                postmap.put("IMAGE URI",download_uri);
                                postmap.put("POSTED BY", user_id);
                                postmap.put("TIME", randomname);

                                firebase.collection("POSTS").add(postmap);
                            } else {

                                Toast.makeText(NewPost_Activity.this,"ERRR",Toast.LENGTH_SHORT).show();
                            }


                        }
                    });

                }
                else
                    {
                    Toast.makeText(NewPost_Activity.this, "ERROR", Toast.LENGTH_SHORT).show();
                }
            }

        });


        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CropImage.activity()
                        .setGuidelines(CropImageView.Guidelines.ON).setAspectRatio(1, 1)
                        .start(NewPost_Activity.this);
            }
        });
    }
        @Override
        public void onActivityResult ( int requestCode, int resultCode, Intent data){
            super.onActivityResult(requestCode, resultCode, data);
            if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
                CropImage.ActivityResult result = CropImage.getActivityResult(data);
                if (resultCode == RESULT_OK) {
                    postimageURI = result.getUri();
                    imageView.setImageURI(postimageURI);
                } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                    Exception error = result.getError();
                }
            }
        }

    }



